import React, { useEffect, useState } from 'react';
import { FaLinkedin, FaGithub, FaEnvelope, FaArrowUp, FaDownload, FaMapMarkerAlt } from 'react-icons/fa';
import { motion } from 'framer-motion';
import ReactTypingEffect from 'react-typing-effect';
import AboutMe from './AboutMe';
import ProfessionalExperience from './ProfessionalExperience';
import Education from './Education';
import Projects from './Projects';
import Skills from './Skills';
import Certifications from './Certifications';
import ValueProposition from './ValueProposition';
import ContactForm from './ContactForm';
import './ProfilePage.css';

export default function ProfilePage() {
  const [s, setS] = useState(0);
  useEffect(() => {
    const h = () => { const d = document.documentElement.scrollHeight - window.innerHeight; if (d > 0) setS((window.pageYOffset / d) * 100); };
    window.addEventListener('scroll', h, { passive: true });
    return () => window.removeEventListener('scroll', h);
  }, []);
  const go = id => { const el = document.getElementById(id); if (el) window.scrollTo({ top: el.offsetTop - 58, behavior: 'smooth' }); };
  const f = { hidden: { opacity: 0, y: 16 }, visible: { opacity: 1, y: 0, transition: { duration: .4, ease: [.2,0,0,1] } } };
  const S = ({ id, children }) => <motion.section id={id} variants={f} initial="hidden" whileInView="visible" viewport={{ once: true, amount: .1 }}>{children}</motion.section>;

  return (
    <div style={{ background: 'var(--bg)', minHeight: '100vh' }}>
      <div className="progress" style={{ width: `${s}%` }} />

      <nav className="nav">
        <div className="nav-logo">Jihed<span>.</span></div>
        <div className="nav-r">
          {['about','experience','projects','skills','contact'].map(x =>
            <button key={x} className="nav-btn" onClick={() => go(x)}>{x.charAt(0).toUpperCase()+x.slice(1)}</button>
          )}
          <a href={`${process.env.PUBLIC_URL}/JihedOueslati.pdf`} download><button className="btn"><FaDownload style={{ fontSize:'.65rem' }} /> Resume</button></a>
        </div>
      </nav>

      {/* Hero */}
      <header className="hero">
        <div className="wrap" style={{ position: 'relative', zIndex: 2 }}>
          <div className="hero-flex" style={{ display:'flex',alignItems:'center',gap:'2.5rem',flexWrap:'wrap' }}>
            <motion.div initial={{ opacity:0,scale:.92 }} animate={{ opacity:1,scale:1 }} transition={{ duration:.4 }} style={{ flexShrink:0 }}>
              <div style={{ width:140,height:140,borderRadius:16,overflow:'hidden',border:'2px solid var(--border)',background:'var(--bg-2)' }}>
                <img src={`${process.env.PUBLIC_URL}/jihed.png`} alt="Jihed Oueslati" style={{ width:'100%',height:'100%',objectFit:'cover' }} />
              </div>
            </motion.div>
            <div style={{ flex:1,minWidth:240 }}>
              <motion.div initial={{ opacity:0,y:10 }} animate={{ opacity:1,y:0 }} transition={{ delay:.06 }}>
                <div style={{ display:'flex',alignItems:'center',gap:8,marginBottom:8,flexWrap:'wrap' }}>
                  <span className="pill pill-g">Open to work</span>
                  <span style={{ fontSize:'.72rem',color:'var(--text-4)',display:'flex',alignItems:'center',gap:3 }}>
                    <FaMapMarkerAlt style={{ fontSize:'.58rem' }} />Tunis, Tunisia
                  </span>
                </div>
              </motion.div>
              <motion.h1 initial={{ opacity:0,y:10 }} animate={{ opacity:1,y:0 }} transition={{ delay:.12 }}
                style={{ fontSize:'2.2rem',fontWeight:700,lineHeight:1.1,marginBottom:8,color:'var(--navy)',letterSpacing:'-.03em' }}>
                <ReactTypingEffect text={["Jihed Oueslati"]} speed={70} eraseSpeed={50} typingDelay={300} cursor={"|"} />
              </motion.h1>
              <motion.p initial={{ opacity:0,y:10 }} animate={{ opacity:1,y:0 }} transition={{ delay:.18 }}
                style={{ fontSize:'.88rem',color:'var(--text-3)',marginBottom:10,fontWeight:500 }}>
                Software Engineer &middot; QA & Testing &middot; CI/CD &middot; AI Integration
              </motion.p>
              <motion.p initial={{ opacity:0,y:10 }} animate={{ opacity:1,y:0 }} transition={{ delay:.24 }}
                style={{ fontSize:'.88rem',color:'var(--text-3)',lineHeight:1.65,maxWidth:440,marginBottom:16 }}>
                I build tested, reliable software. From automated test generation and CI/CD pipelines 
                to AI-driven quality workflows — I make sure code works before it ships.
              </motion.p>
              <motion.div className="soc-row" initial={{ opacity:0,y:10 }} animate={{ opacity:1,y:0 }} transition={{ delay:.3 }}
                style={{ display:'flex',gap:6 }}>
                <a href="https://linkedin.com/in/jihed-oueslati-7981b91ba" target="_blank" rel="noopener noreferrer" className="soc"><FaLinkedin /></a>
                <a href="https://github.com/Jihedoueslatiii" target="_blank" rel="noopener noreferrer" className="soc"><FaGithub /></a>
                <a href="mailto:oueslatiijihed@outlook.com" className="soc"><FaEnvelope /></a>
              </motion.div>
            </div>
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="wrap" style={{ paddingBottom:'3rem' }}>
        <div style={{ display:'flex',flexDirection:'column',gap:'2.25rem' }}>
          <S id="about"><AboutMe /></S>
          <div className="divider" />
          <S><ValueProposition /></S>
          <div className="divider" />
          <S id="experience"><ProfessionalExperience /></S>
          <div className="divider" />
          <S id="education"><Education /></S>
          <div className="divider" />
          <S id="projects"><Projects /></S>
          <div className="divider" />
          <S id="skills"><Skills /></S>
          <div className="divider" />
          <S><Certifications /></S>
          <div className="divider" />
          <S id="contact">
            <div className="contact-sec">
              <div className="label">Contact</div>
              <h2 className="heading" style={{ marginBottom:4 }}>Let's work together</h2>
              <p style={{ color:'var(--text-3)',fontSize:'.86rem',marginBottom:'1.25rem' }}>Got a project or opportunity? Drop me a message.</p>
              <ContactForm />
            </div>
          </S>
        </div>
      </main>

      {/* Footer */}
      <footer className="footer">
        <div style={{ display:'flex',justifyContent:'center',gap:6,marginBottom:'.6rem' }}>
          <a href="https://linkedin.com/in/jihed-oueslati-7981b91ba" target="_blank" rel="noopener noreferrer" className="soc" style={{ width:32,height:32,fontSize:'.85rem' }}><FaLinkedin /></a>
          <a href="https://github.com/Jihedoueslatiii" target="_blank" rel="noopener noreferrer" className="soc" style={{ width:32,height:32,fontSize:'.85rem' }}><FaGithub /></a>
          <a href="mailto:oueslatiijihed@outlook.com" className="soc" style={{ width:32,height:32,fontSize:'.85rem' }}><FaEnvelope /></a>
        </div>
        <p style={{ color:'var(--text-4)',fontSize:'.74rem' }}>
          Built by <span style={{ color:'var(--text-2)',fontWeight:600 }}>Jihed Oueslati</span> &copy; 2025
        </p>
      </footer>

      {s > 10 && (
        <motion.button initial={{ opacity:0 }} animate={{ opacity:1 }}
          onClick={() => window.scrollTo({ top:0,behavior:'smooth' })}
          className="btn" style={{ position:'fixed',bottom:'1rem',right:'1rem',zIndex:80,width:36,height:36,padding:0,display:'flex',alignItems:'center',justifyContent:'center',borderRadius:8 }}>
          <FaArrowUp style={{ fontSize:'.75rem' }} />
        </motion.button>
      )}
    </div>
  );
}
