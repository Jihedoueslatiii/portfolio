import React from 'react';
import { useState } from 'react';

const experiences = [
  {
    title: 'Summer Internship at Safran – QRQC',
    date: '01/07/2024 – 15/08/2024',
    location: 'Tunis, Tunisia',
    description: 'Developed a web-based platform to support QRQC (Quick Response Quality Control) processes. Implemented data processing pipelines, integrated SQL Server for structured data management, and built interactive dashboards using Angular. Developed backend services with Spring Boot and applied LLM techniques to assist in automated analysis and decision support for production quality.',
    keywords: ['Angular', 'Spring Boot', 'SQL Server', 'Data Processing', 'LLM', 'QRQC'],
    logo: 'safran.png',
    isImage: true
  },
  {
    title: 'Summer Internship at Secure Shield Consulting',
    date: '01/07/2024 – 15/08/2024',
    location: 'Menzah 5',
    description: 'Developed a comprehensive web application for file management. Implemented user authentication and file upload features. Utilized React, Node.js, Express, and MongoDB for a scalable solution.',
    keywords: ['React', 'NodeJs', 'Express JS', 'MongoDB'],
    logo: 'secureshield.png',
    isImage: true
  },
  {
    title: 'End of Studies Internship at BNA',
    date: '02/2023 – 06/2023',
    location: 'Tunis',
    description: 'Implemented a sophisticated monitoring solution using Zabbix. Configured SNMP for efficient network management. Conducted extensive security tests and attack simulations to enhance system resilience.',
    keywords: ['Zabbix', 'Network Administration', 'SNMP', 'Security', 'Attacks Test'],
    logo: 'bna.png',
    isImage: true
  },
  {
    title: 'End of Year Internship at BNA',
    date: '07/2022 – 08/2022',
    location: 'Tunis',
    description: 'Developed a web application for managing customer information. Created functionalities for profile management and transaction tracking. Employed HTML, CSS, JavaScript, and PHP for a responsive design.',
    keywords: ['HTML', 'CSS', 'JS', 'PHP'],
    logo: 'bna.png',
    isImage: true
  },
];

// Simplified icon representation using emojis 
const keywordIcons = {
  React: '⚛️',
  NodeJs: '📦',
  'Express JS': '🚂', 
  MongoDB: '🍃',
  HTML: '📝',
  CSS: '🎨',
  JS: '⚡', 
  PHP: '🐘',
  Zabbix: '📊',
  'Network Administration': '🌐',
  SNMP: '📡',
  Security: '🔒', 
  'Attacks Test': '🛡️',
  Angular: '🅰️',
  'Spring Boot': '🍃',
  'SQL Server': '🗄️',
  'Data Processing': '⚙️',
  LLM: '🤖',
  QRQC: '✅'
};

const VerticalTimeline = () => {
  const [hoveredIndex, setHoveredIndex] = useState(null);
  const [imageErrors, setImageErrors] = useState({});

  const handleImageError = (index) => {
    setImageErrors(prev => ({
      ...prev,
      [index]: true
    }));
  };

  const renderLogo = (exp, index) => {
    if (exp.isImage && !imageErrors[index]) {
      return (
        <img
          src={`/safran.png`}
          alt={`${exp.title} logo`}
          className="w-10 h-10 object-cover rounded-full"
          onError={() => handleImageError(index)}
          onLoad={() => console.log('Image loaded successfully')}
        />
      );
    }
    
    // Fallback to emoji or default icon
    return (
      <div className="text-2xl">
        {exp.logo.includes('.') ? '🏢' : exp.logo}
      </div>
    );
  };

  return (
    <div className="relative border-l-4 border-yellow-500 ml-6 mt-12">
      {experiences.map((exp, index) => (
        <div
          key={index}
          className="mb-12 ml-6 relative"
          onMouseEnter={() => setHoveredIndex(index)}
          onMouseLeave={() => setHoveredIndex(null)}
        >
          {/* Timeline Marker */}
          <span className="absolute -left-10 top-0 flex items-center justify-center w-14 h-14 bg-gray-700 border-4 border-yellow-500 rounded-full shadow-lg">
            {renderLogo(exp, index)}
          </span>

          {/* Timeline Content */}
          <div className={`bg-gradient-to-r from-gray-700 to-gray-900 text-white p-4 rounded-md shadow-md border-2 border-yellow-500 transition-transform ${hoveredIndex === index ? 'scale-105' : ''}`}>
            <h3 className="text-xl font-bold text-yellow-400">{exp.title}</h3>
            <p className="text-sm text-gray-400">
              <strong>{exp.date} | {exp.location}</strong>
            </p>
            <p className="mt-2 text-sm text-gray-300">{exp.description}</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {exp.keywords.map((keyword, idx) => (
                <div key={idx} className="flex items-center bg-gray-800 px-2 py-1 rounded-md text-sm text-yellow-400">
                  <span className="mr-1">{keywordIcons[keyword] || '🔧'}</span>
                  <span>{keyword}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default VerticalTimeline;